# Building MyPay Android APK

## Overview

MyPay is packaged as a native Android APK using **Capacitor**. The React web app is built with Vite and bundled inside the APK — the app runs completely on-device without requiring a browser.

- **App ID:** `com.mypay.app`
- **App Name:** MyPay
- **Min Android:** API 24 (Android 7.0 Nougat)
- **Target Android:** API 36

---

## Before You Build

You need one of:

| Option | Tools Required |
|---|---|
| **Local (Android Studio)** | Android Studio Ladybug+, JDK 17, SDK API 36 |
| **GitHub Actions (CI)** | Push to GitHub — APK is built automatically |

---

## Option 1 — GitHub Actions (Recommended, zero local setup)

1. Push this repo to GitHub
2. Add one secret in **Settings → Secrets → Actions**:
   - `VITE_API_BASE_URL` — your deployed API server URL (e.g. `https://your-app.replit.app`)
3. The workflow at `.github/workflows/build-android-apk.yml` triggers automatically on every push to `main`
4. Go to **Actions → Build Android APK → Artifacts** and download `MyPay-debug-<sha>.apk`

For a signed release APK, also add:
- `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`
- Trigger **workflow_dispatch** with `release: true`

---

## Option 2 — Local Build with Android Studio

### Step 1: Configure API base URL

Create `artifacts/web-app/.env.local`:

```
VITE_API_BASE_URL=https://your-deployed-api.replit.app
```

> Leave blank if API and web app run on the same domain.

### Step 2: Build web assets

```bash
cd artifacts/web-app
pnpm run build
```

This produces `artifacts/web-app/dist/public/`.

### Step 3: Sync to Android project

```bash
npx cap sync android
```

This copies the web build into `android/app/src/main/assets/public/`.

### Step 4: Open in Android Studio

```bash
npx cap open android
```

Or manually open `artifacts/web-app/android/` as a project in Android Studio.

### Step 5: Build the APK

In Android Studio:
- **Debug APK:** `Build → Build Bundle(s) / APK(s) → Build APK(s)`
- **Release APK:** `Build → Generate Signed Bundle / APK → APK → follow wizard`

Output: `android/app/build/outputs/apk/debug/app-debug.apk`

---

## Option 3 — Command Line Only

```bash
# 1. Build web assets
cd artifacts/web-app
VITE_API_BASE_URL=https://your-api.replit.app pnpm run build

# 2. Sync
npx cap sync android

# 3. Build APK (requires ANDROID_HOME env var pointing to SDK)
cd android
chmod +x gradlew
./gradlew assembleDebug

# APK output:
# android/app/build/outputs/apk/debug/app-debug.apk
```

---

## Installing the APK on an Android Device

### Via ADB (USB cable)

```bash
adb install android/app/build/outputs/apk/debug/app-debug.apk
```

### Via file transfer

1. Copy the `.apk` file to your Android device
2. On the device: go to **Settings → Security → Install unknown apps** → allow your file manager
3. Open the `.apk` file and tap **Install**
4. MyPay appears in your app drawer and on the home screen

---

## Hosting the APK for Download

To make the "Download APK" button on the install page work:

1. Upload your built APK to:
   - GitHub Releases (recommended: tag a release, upload the APK as an asset)
   - Or any static file host
2. Set the download URL as a Replit secret:
   - **Name:** `VITE_APK_DOWNLOAD_URL`
   - **Value:** `https://github.com/your-org/mypay/releases/download/v1.0/MyPay.apk`
3. Rebuild the web app — the install page will now show the "Download APK" button

---

## Signing for Play Store

1. Generate a keystore:
   ```bash
   keytool -genkey -v -keystore release.keystore -alias mypay \
     -keyalg RSA -keysize 2048 -validity 10000
   ```
2. Place `release.keystore` in `artifacts/web-app/android/app/`
3. Add to `android/app/build.gradle`:
   ```gradle
   signingConfigs {
     release {
       storeFile file("release.keystore")
       storePassword System.getenv("KEYSTORE_PASSWORD")
       keyAlias System.getenv("KEY_ALIAS")
       keyPassword System.getenv("KEY_PASSWORD")
     }
   }
   buildTypes {
     release {
       signingConfig signingConfigs.release
       minifyEnabled true
       proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
     }
   }
   ```

---

## Estimated APK Sizes

| Build Type | Estimated Size |
|---|---|
| Debug APK | ~30–40 MB |
| Release APK (minified) | ~20–30 MB |

Size is dominated by the Capacitor Android runtime (~10 MB) and bundled web assets.
