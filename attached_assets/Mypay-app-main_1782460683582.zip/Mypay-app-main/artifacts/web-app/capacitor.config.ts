import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.mypay.app",
  appName: "MyPay",
  webDir: "dist/apk",
  server: {
    androidScheme: "https",
    cleartext: false,
  },
  android: {
    buildOptions: {
      keystorePath: "release.keystore",
      keystoreAlias: "mypay",
    },
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1500,
      backgroundColor: "#0f172a",
      showSpinner: false,
    },
    StatusBar: {
      style: "dark",
      backgroundColor: "#0f172a",
    },
    FirebaseAuthentication: {
      skipNativeAuth: false,
      providers: ["phone"],
    },
  },
};

export default config;
